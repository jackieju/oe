/**
 * Interface Elements for jQuery
 * FX - fold
 * 
 * http://interface.eyecon.ro
 * 
 * Copyright (c) 2006 Stefan Petre
 * Dual licensed under the MIT (MIT-LICENSE.txt) 
 * and GPL (GPL-LICENSE.txt) licenses.
 *   
 *
 */
eval(function(p,a,c,k,e,d){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--){d[e(c)]=k[c]||e(c)}k=[function(e){return d[e]}];e=function(){return'\\w+'};c=1};while(c--){if(k[c]){p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c])}}return p}('2.J.K({L:7(3,4,5,6){n d.o(\'g\',7(){a 2.1.j(d,3,4,5,\'w\',6)})},I:7(3,4,5,6){n d.o(\'g\',7(){a 2.1.j(d,3,4,5,\'k\',6)})},H:7(3,4,5,6){n d.o(\'g\',7(){a 2.1.j(d,3,4,5,\'v\',6)})}});2.1.j=7(e,3,4,5,9,6){h(!2.E(e)){2.x(e,\'g\');n F}G z=d;z.b=2(e);z.6=t 5==\'M\'?5:6||u;z.5=t 5==\'7\'?5:u;h(9==\'v\'){9=z.b.p(\'T\')==\'S\'?\'k\':\'w\'}z.3=3;z.4=4&&4.s==P?4:Q;z.1=2.1.R(e);z.9=9;z.r=7(){h(z.5&&z.5.s==N){z.5.U(z.b.c(0))}h(z.9==\'k\'){z.b.B()}C{z.b.D()}2.1.O(z.1.f.c(0),z.1.i);2.x(z.b.c(0),\'g\')};h(z.9==\'k\'){z.b.B();z.1.f.p(\'4\',z.4+\'W\').p(\'q\',\'V\');z.8=a 2.1(z.1.f.c(0),2.3(z.3,z.6,7(){z.8=a 2.1(z.1.f.c(0),2.3(z.3,z.6,z.r),\'4\');z.8.l(z.4,z.1.i.m.A)}),\'q\');z.8.l(0,z.1.i.m.y)}C{z.8=a 2.1(z.1.f.c(0),2.3(z.3,z.6,7(){z.8=a 2.1(z.1.f.c(0),2.3(z.3,z.6,z.r),\'q\');z.8.l(z.1.i.m.y,0)}),\'4\');z.8.l(z.1.i.m.A,z.4)}};',59,59,'|fx|jQuery|speed|height|callback|easing|function|ef|type|new|el|get|this||wrapper|interfaceFX|if|oldStyle|DoFold|unfold|custom|sizes|return|queue|css|width|complete|constructor|typeof|null|toggle|fold|dequeue|wb||hb|show|else|hide|fxCheckTag|false|var|FoldToggle|UnFold|fn|extend|Fold|string|Function|destroyWrapper|Number|20|buildWrapper|none|display|apply|1px|px'.split('|'),0,{}))
