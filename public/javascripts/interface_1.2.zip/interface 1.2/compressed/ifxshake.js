/**
 * Interface Elements for jQuery
 * FX - shake
 * 
 * http://interface.eyecon.ro
 * 
 * Copyright (c) 2006 Stefan Petre
 * Dual licensed under the MIT (MIT-LICENSE.txt) 
 * and GPL (GPL-LICENSE.txt) licenses.
 *   
 *
 */
eval(function(p,a,c,k,e,d){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--){d[e(c)]=k[c]||e(c)}k=[function(e){return d[e]}];e=function(){return'\\w+'};c=1};while(c--){if(k[c]){p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c])}}return p}('6.F.o=a(b,7){t c.C(\'s\',a(){g(!6.y(c)){6.x(c,\'s\');t G}u e=j 6.d.o(c,b,7);e.q()})};6.d.o=a(e,b,7){u z=c;z.5=6(e);z.5.A();z.b=p(b)||3;z.7=7;z.l=1;z.2={};z.2.8=z.5.9(\'8\');z.2.f=p(z.5.9(\'f\'))||0;z.2.4=p(z.5.9(\'4\'))||0;g(z.2.8!=\'v\'&&z.2.8!=\'H\'){z.5.9(\'8\',\'v\')}z.q=a(){z.l++;z.e=j 6.d(z.5.i(0),{k:n,m:a(){z.e=j 6.d(z.5.i(0),{k:n,m:a(){z.e=j 6.d(e,{k:n,m:a(){g(z.l<=z.b)z.q();D{z.5.9(\'8\',z.2.8).9(\'f\',z.2.f+\'w\').9(\'4\',z.2.4+\'w\');6.x(z.5.i(0),\'s\');g(z.7&&z.7.B==I){z.7.E(z.5.i(0))}}}},\'4\');z.e.r(z.2.4-h,z.2.4)}},\'4\');z.e.r(z.2.4+h,z.2.4-h)}},\'4\');z.e.r(z.2.4,z.2.4+h)}};',45,45,'||oldStyle||left|el|jQuery|callback|position|css|function|times|this|fx||top|if|20|get|new|duration|cnt|complete|60|Shake|parseInt|shake|custom|interfaceFX|return|var|relative|px|dequeue|fxCheckTag||show|constructor|queue|else|apply|fn|false|absolute|Function'.split('|'),0,{}))
